import PermissionsReducer from "./PermissionsReducer";

export { PermissionsReducer };
