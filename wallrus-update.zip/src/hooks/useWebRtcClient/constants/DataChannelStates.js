export const NULL = "NULL";
export const READY = "READY";
export const BUSY = "BUSY";
