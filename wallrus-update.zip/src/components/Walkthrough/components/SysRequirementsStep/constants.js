export const OS_RECOMMENDATION = "OS_RECOMMENDATION";
export const BROWSER_RECOMMENDATION = "BROWSER_RECOMMENDATION";
export const CONNECTION_RECOMMENDATION = "CONNECTION_RECOMMENDATION";

export const OS_macOS = "macOS";
export const OS_iOS = "iOS";
export const OS_Windows = "Windows";
export const OS_Android = "Android";
export const OS_Linux = "Linux";

export const BR_Firefox = "Firefox";
export const BR_Safari = "Safari";
export const BR_Chrome = "Chrome";
