import BaseDialog from "./BaseDialog";
import InstructionDialog from "./InstructionDialog";
import SwipeDialog from "./SwipeDialog";

export { BaseDialog, InstructionDialog, SwipeDialog };
