export const ON_PRESSED = "ON_PRESSED";
export const ON_RELEASED = "ON_RELEASED";
export const ON_DRAG_START = "ON_DRAG_START";
export const ON_DRAG_STOP = "ON_DRAG_STOP";
