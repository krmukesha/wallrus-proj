export const PER_FRAME = "IPT_MODE_PER_FRAME";
export const INTERVAL = "IPT_MODE_INTERVAL";
