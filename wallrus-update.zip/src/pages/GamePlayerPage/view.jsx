import React from "react";
import PropTypes from "prop-types";

const GamePlayerPageView = ({ children }) => <>{children}</>;
GamePlayerPageView.propTypes = {
  children: PropTypes.object,
};

export default GamePlayerPageView;
